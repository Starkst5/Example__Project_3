import React from 'react';
import { Posts_Collection_Access } from './../api/posts_collection.js';

export default class AddTopics extends React.Component {

  processFormData(event) {
    event.preventDefault();
    let newTopic = event.target.formInputNameAttribute.value.trim();

    if (newTopic) {
      Posts_Collection_Access.insert({
        topic: newTopic,
        up_votes: 0,
        down_votes: 0,
        date_added: new Date(),
      });

      event.target.formInputNameAttribute.value = '';
    }
  }

  render() {
    return (
      <div className='post-block-item-style'>
        <form className='form' onSubmit={this.processFormData.bind(this)}>
          <input
            className='form__input'
            type='text'
            name='formInputNameAttribute'
            placeholder='Enter a topic'
          />
          <button className='button'>Add Topic</button>
        </form>
      </div>
    );
  }
};