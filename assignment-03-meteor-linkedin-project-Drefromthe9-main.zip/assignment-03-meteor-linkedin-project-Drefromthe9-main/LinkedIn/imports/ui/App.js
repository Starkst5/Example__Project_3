import React from 'react';
import PropTypes from 'prop-types';
import TitleBar from './Title.js';
import AddTopics from './NewTopic.js';
import TopicList from './AllTopics.js';
import Footer from './Footer.js';

export default class App extends React.Component {
  render() {
    return (
      <>
        <div className='background'>
        <TitleBar
          title={this.props.passedPropTitle}
          moderator={this.props.passedPropModerator}/>
        <div className='wrapper'>
          <AddTopics />
          <TopicList passed_posts={this.props.passedPropAllPosts}/>
        </div>
        <Footer footerText={this.props.passedPropFooter} />
        </div>
      </>
    )
  }

};

App.propTypes = {
  passedPropTitle: PropTypes.string.isRequired,
  passedPropAllPosts: PropTypes.array.isRequired
};