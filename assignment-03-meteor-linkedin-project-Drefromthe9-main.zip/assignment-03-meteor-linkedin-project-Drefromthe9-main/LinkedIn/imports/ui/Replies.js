import React from 'react';
import {Replies_Collection_Access} from './../api/replies_collection.js';
import PropTypes from 'prop-types';


export default class MakeReplies extends React.Component{

  render(){
    let single_item_class_name =
                `single-block-item-style
                single-block-item-style--position-${this.props.reply_prop_obj.rank}`;
    let possible_link = this.props.reply_prop_obj.reply_topic;
    if (this.props.reply_prop_obj.reply_topic.includes('http')){
      possible_link = <a href={this.props.reply_prop_obj.reply_topic}>{this.props.reply_prop_obj.reply_topic}</a>;
    };
    return (
      <>
        <div key={this.props.reply_prop_obj._id} className={single_item_class_name}>

          <div className='post'>
            <div>
              <h3 className='post__topic'>{possible_link}</h3>
              <p className='post__stats'>{this.props.reply_prop_obj.total_reply_votes} total vote[s] <br />
              {this.props.reply_prop_obj.reply_up_votes} up {'\uD83D\uDC4D'} {this.props.reply_prop_obj.reply_down_votes} down {'\uD83D\uDC4E'}
                </p> 
            </div>
            <div className='post__actions'>
              <button className='button button--round' onClick={() => {  
                Replies_Collection_Access.update({_id: this.props.reply_prop_obj._id},
                  {$inc: {reply_up_votes: 1, total_reply_votes: 1}})}}>{'\uD83D\uDC4D'} </button>
              <button className='button button--round' onClick={() => {
                Replies_Collection_Access.update({_id: this.props.reply_prop_obj._id},
                  {$inc: {reply_down_votes: 1, total_reply_votes: 1}})}}>{'\uD83D\uDC4E'}</button>
              <button className='button button--round' onClick={() => {
                Replies_Collection_Access.remove({_id: this.props.reply_prop_obj._id})
              }}>X</button>
            </div>

          </div>
        </div>
      </>
    );
  }
};
MakeReplies.propTypes = {
  reply_prop_obj: PropTypes.object.isRequired,
};