import {Mongo} from 'meteor/mongo';
import numeral from 'numeral';

export const Posts_Collection_Access = new Mongo.Collection('posts_collection');

export const Rank_posts = (posts_collections) => {

    let rank = 1;

    return posts_collections.map((post, index) => {
        console.log(post.topic + ' ' + post.up_votes + ' ' + post.down_votes  + ' ' + index);
        if ( index !== 0 && posts_collections[index -1].up_votes > post.up_votes) {
            rank++;
        }
        
        return {
            ...post,
            rank,
            position: numeral(rank).format('0o'),
        };
    });
};