import {Mongo} from 'meteor/mongo';


export const Replies_Collection_Access = new Mongo.Collection('replies_collection');

export const Rank_replies = (passed_replies_collections) => {

    let rank = 1;

    return passed_replies_collections.map((reply, index) => {

        if ( index !== 0 && passed_replies_collections[index -1].total_reply_votes > reply.total_reply_votes) {
            rank++;
        }

        return {
            ...reply,
            rank,
        
        };
    });
};