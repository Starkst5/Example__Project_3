import React from 'react';
import ReactDOM from 'react-dom';
import {Meteor} from 'meteor/meteor';
import {Tracker} from 'meteor/tracker';
import { Posts_Collection_Access , Rank_posts}
         from '../imports/api/posts_collection';
import App from '../imports/ui/App.js';


Meteor.subscribe("posts_collection");
Meteor.subscribe("replies_collection");



Meteor.startup(() => {
  Tracker.autorun(() => { 

   
    const allPosts = Posts_Collection_Access.find({}, 
                                              {sort: {date_added: -1}}).fetch();
    let title = 'Welcome to LinkedIn';

   
    let positioned_posts = Rank_posts(allPosts);
    
    ReactDOM.render(<App 
      passedPropTitle={title} 
      passedPropModerator={'dre'} 
      passedPropAllPosts={positioned_posts}
      passedPropFooter = {'\u00A9 LinkedIn'}
      />, document.getElementById('react-target'));
  });

});