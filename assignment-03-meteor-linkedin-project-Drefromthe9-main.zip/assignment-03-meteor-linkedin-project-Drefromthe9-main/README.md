[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/F3r5kZbp)
# meteor LinkedIn v3.1.2 Project

<p>Please reference blackboard for the most current assignment instructions/requirements/points.</p>

<p>Don't forget to use <strong>npx concurrently --kill-others "npm run watch:css" "meteor run"<strong></p>